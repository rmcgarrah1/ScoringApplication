package androidatc.com.scoringapplication

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_main.view.*
import kotlinx.android.synthetic.main.fragment_login.*
import kotlinx.android.synthetic.main.fragment_login.view.*



class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        login.setOnClickListener { onLoginButtonClicked(this.login) }
    }

    fun onLoginButtonClicked(view: View) {
        var user=username.text
        var pass=password.text
        if (user.equals("test")&& pass.equals("111111")){
            println("Login successful")
        }
        else{
            println("Login failed")
        }


    }

    fun goHelp(view: View) {
        var intent = Intent (this, Help::class.java)

        startActivity(intent)


    }

    fun goPreferences(view: View ) {
        var intent = Intent(this, Preferences::class.java)

        startActivity(intent)
    }

}